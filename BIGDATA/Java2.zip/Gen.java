class Gen<T> {
	T ob; 
	private java.util.ArrayList<T> list = new java.util.ArrayList<>();
	Gen(T o) {
		ob = o;
	}
	T getob() {
		return ob;
	}
	void add(T o){
		list.add(o);
	}
	void showType() {
		System.out.println("Type of T is " +
		ob.getClass().getName());
	}

	@Override
	public String toString(){
		return "This object's overriden toString method output is overriden";
	}
}

