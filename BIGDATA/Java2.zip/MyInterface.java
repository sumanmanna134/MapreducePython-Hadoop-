interface MyInterface<T>{
	T getInterfaceObj();
}