class GenThirdSubclass  extends Gen<Integer>{
	GenThirdSubclass(Integer o){
		super(o);
	}
	void newMethod(){
		System.out.println("This is the third subclass method");
	}
}
