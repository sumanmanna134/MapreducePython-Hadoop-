class MyConcreteClass<T> implements MyInterface<T>{
	T obj;
	MyConcreteClass(T o){
		obj = o;
	}
	public T getInterfaceObj(){
		System.out.println("the object is "+obj);
		return obj;
	}
}
