class GenAnotherSubclass<T, V>  extends Gen<T>{
	V ob2;
	GenAnotherSubclass(T o, V o2){
		super(o);
		ob2 = o2;
	}
	V getMyOb(){
		return ob2;
	}
	void newMethod(){
		System.out.println("This is a another subclass method with its constructor param value " + ob2);
	}
}
