class GenDemo {
	
	//generic method specifies parameter type before return type
	public static <P> void anotherMethod(P[] list){
		for (int i=0; i < list.length; i++){
			System.out.println(list[i]+" ");
		}
	}

	public static void main(String args[]) {
	Gen<Integer> iOb;
	iOb = new Gen<Integer>(88);
	iOb.showType();
	int v = iOb.getob();
	System.out.println("value: " + v);
	System.out.println();
	iOb.add(new Integer(5));
	iOb.add(5);
	//incomaptible types
	//iOb.add(new String("abcd"));
	
	Gen<String> strOb = new Gen<String> ("Generics Test");
	strOb.showType();
	String str = strOb.getob();
	System.out.println("value: " + str);
	System.out.println("from toString method: " + strOb);

	GenSubclass<String> subOb = new GenSubclass<>("abcd");
	subOb.showType();
	subOb.newMethod();
	System.out.println("value: " + subOb.getob());
	
	GenSubclass<String> subOb2 = new GenSubclass<String>("abcde");
	subOb2.showType();
	subOb2.newMethod();
	System.out.println("value: " + subOb2.getob());

	GenAnotherSubclass<String, String> subOb3 = new GenAnotherSubclass<>("abcdef","1234");
	subOb3.showType();
	subOb3.newMethod();
	System.out.println("value: " + subOb3.getob());

	GenAnotherSubclass<String, Integer> subOb4 = new GenAnotherSubclass<>("abcdefg",1234);
	subOb4.showType();
	subOb4.newMethod();
	System.out.println("output from getMyOb method of subclass "+subOb4.getMyOb());
	System.out.println("value: " + subOb4.getob());
	
	MyConcreteClass<Integer> intfOb5 = new MyConcreteClass<>(23);
	System.out.println("value: " + intfOb5.getInterfaceObj());
	
	//generic method demo
	Integer[] integers = {1, 2, 3, 4, 5};
	String[] strings = {"London", "Paris", "New York", "Austin"};
	GenDemo.anotherMethod(integers);
	GenDemo.anotherMethod(strings);

	GenThirdSubclass subOb5 = new GenThirdSubclass(5);
	subOb5.newMethod();

	}
}