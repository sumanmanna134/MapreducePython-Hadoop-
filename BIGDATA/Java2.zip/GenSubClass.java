class GenSubclass<T>  extends Gen<T>{
	GenSubclass(T o){
		super(o);
	}
	void newMethod(){
		System.out.println("This is a subclass method");
	}
}