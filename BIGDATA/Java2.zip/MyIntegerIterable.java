import java.util.*;
class MyIntegerIterable implements Iterable<Integer>{
	List<Integer> strList;
	MyIntegerIterable(List<Integer> mylist){
		strList = mylist;
	}
	@Override
	public Iterator<Integer> iterator(){
		return strList.iterator();
	}
	public static void main(String args[]){
		List<Integer> list = Arrays.asList(5,6,7,8);
		MyIntegerIterable mii = new MyIntegerIterable(list);
		for (Integer element : mii){
			System.out.print(element+" ");
		}
	}
}
		