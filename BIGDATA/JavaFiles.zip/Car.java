class Car extends Vehicle implements CarIntf {
	int mileage;
	double fuel = 10.32;
	long kmCovered = 1000000;
	Integer myint = new Integer(6);
	float wheelbase = 30f;
	char c = 'A';
	int myArray[] = new int[10];

	public void m1(int m){
		//System.out.println("method m1" + " the constant from interface= " +CarIntf.POLLUTION_STD1);
	}
	public void m2(int m){
		System.out.println("method m2");
	}

	
	void setMileage(int mileage){
		//int mileage;
		this.mileage = mileage;
		System.out.println("the comparion result ===>" + myint.compareTo(new Integer(5)));
	}
	
	public static void main(String args[]){
		System.out.println("This line is from my main program");
		
		Car c1 = new Car();
		c1.mVehicle();
		c1.m1(5);
		
		c1.setMileage(82);
		System.out.println("The mileage of my car is " + c1.mileage);
		System.out.println("The fuel of my car is " + c1.fuel);
		System.out.println("The wheelbase of my car is " + c1.wheelbase);
		System.out.println("The coverage of my car is " + c1.kmCovered);
		System.out.println("The char var is " + c1.c);
		System.out.println("the char for my mileage is " + (char)c1.mileage);
		Double d = new Double(32.3334);
		Double d2 = new Double(c1.fuel);
		Double d3 = new Double(args[0]);
		double d4 = Double.parseDouble(args[0]);
		System.out.println("the value of Double object is"+d3); 
		System.out.println("the value of Double object is"+d4); 
		System.out.println("tell me is the values are same " + d2.compareTo(d3));
		for (int i=0; i < c1.myArray.length; i++){
			c1.myArray[i] = i+20;
		}
		for (int i=0; i < c1.myArray.length; i++){
			System.out.print(c1.myArray[i] + " ");
		}
		String s = new String("this is my new string");
		System.out.println(s);
		boolean condition = true;
		if(condition & 3>5){
			System.out.println("the true condiiton is " + condition);
		}else{
			System.out.println("the false condiiton is " + condition);
		}
		int j = Integer.parseInt("12");
		System.out.println(j);
		
		Integer myArray2[] = new Integer[5];
		myArray2[0]= 5;	
		myArray2[1]= new Integer(5);
		System.out.println(myArray2[0] + " " + myArray2[1]);
		int myArray[] = new int[10];
		System.out.println("myArray----" + myArray[0]);
		//int p = 4.5f;
		double q = 4;
		Integer r = 5;
		//Integer s = 5.4;
		//Integer t = new Integer("6.5");
		//System.out.println(t);
		Integer u = new Integer("6");
		System.out.println(u);
		CarSecurity cs = new CarSecurity();
		cs.showSecurity();
		CarSecurity.giveWarning();
		
	}
}