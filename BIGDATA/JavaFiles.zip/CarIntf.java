interface CarIntf{
	static final int POLLUTION_STD1 = 1;
	static final int POLLUTION_STD2 = 2;
	public void m1(int m);
	public void m2(int m);
}