import java.util.*;
class AllAboutArrays{
	public static void main(String args[]){
		int a[] = new int[10];
		for(int i = 0; i<a.length;i++){
			a[i]=i+10;
		}
		for (int element : a){
			System.out.print(element +" ");
		}
		String a2[] = new String[10];
		for(int i = 0; i<a.length;i++){
			a2[i]= Integer.toString(i+10);
		}
		for (String e : a2){
			System.out.print(e +" ");
		}

		ArrayList<Integer> al = new ArrayList<>();
ArrayList<String> a2 = new ArrayList<>();

ArrayList<Float> a3 = new ArrayList<>();


		for(int i=0; i<5;i++){
			al.add(i+100);
		}
		for (Integer element : al){
			System.out.print(element +" ");
		}
	}
}