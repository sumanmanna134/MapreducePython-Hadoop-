//run using java FileIO <input_filename> <output_filename>
//replace the placeholders by your chosen input and output filenames

import java.io.*;
public class FileIO{
	public static void main(String args[]) {
		for(int index=0;index<256; index++)
			System.out.print((char)index+" ");
		FileInputStream fin;
		FileOutputStream fout;
		int i;
		int size;
		try{
			fin = new FileInputStream(args[0]);
			fout = new FileOutputStream(args[1]);
		}catch (FileNotFoundException e){
			System.out.println("File was not found");
			return;
		}

		try{
			do{
				i= fin.read();
				if(i!=-1) {
					System.out.print((char)i);
					fout.write(i);
				}
			}while(i!=-1);
		}catch (IOException e){
			System.out.println("Error while reading file");
		}
		try{
			fin.close();
			fout.close();
		}catch (IOException e){
			System.out.println("Error while closing file");
		}
	}
}

