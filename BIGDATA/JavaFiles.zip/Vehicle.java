class Vehicle{
	void mVehicle(){
		System.out.println("from inside mVehicle method of super class");
	}
}