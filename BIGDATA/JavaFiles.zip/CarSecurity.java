class CarSecurity{
	public void showSecurity(){
		System.out.println("The car's security is foolproof!!!!!!!");
	}
	public static void giveWarning(){
		System.out.println("Giving warning==========!!!!!!!!!");
	}
}